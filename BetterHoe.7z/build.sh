dotnet run --project ./CakeBuild/CakeBuild.csproj -- "$@"
